#! /bin/sh
. env.sh

python $SCRIPTROOT/loadMaster.py $SCHEMAPATH/namesMST.xlsx


