#! /bin/sh

cd $1
mkdir $2
