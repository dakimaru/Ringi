#! /bin/sh

sudo /usr/libexec/slapd -d -1 & > /dev/null
